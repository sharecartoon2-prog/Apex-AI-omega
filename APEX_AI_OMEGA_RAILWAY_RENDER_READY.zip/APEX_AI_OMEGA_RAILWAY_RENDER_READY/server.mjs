import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const PORT=Number(process.env.PORT||8787);
const DATA=path.resolve(process.env.APEX_DATA_DIR||path.join(__dirname,'data'));
fs.mkdirSync(DATA,{recursive:true});
const DB=path.join(DATA,'omega-state.json');
const now=()=>new Date().toISOString();
const id=(p)=>p+'_'+crypto.randomBytes(8).toString('hex');
function load(){try{return JSON.parse(fs.readFileSync(DB,'utf8'));}catch{return {users:{},projects:{},goals:{},tasks:{},executions:{},memory:{},permissions:{},approvals:{},schedules:{},audit:[],notifications:[],events:[]};}}
let state=load();
function save(){fs.writeFileSync(DB,JSON.stringify(state,null,2));}
function send(res,status,obj,headers={}){const b=Buffer.from(JSON.stringify(obj));res.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':b.length,'cache-control':'no-store',...headers});res.end(b);}
function html(res,file){const b=fs.readFileSync(file);res.writeHead(200,{'content-type':'text/html; charset=utf-8','content-length':b.length,'cache-control':'no-cache'});res.end(b);}
async function body(req){let s='';for await(const c of req)s+=c;if(!s)return{};try{return JSON.parse(s)}catch{return{_raw:s}}}
function audit(event,extra={}){state.audit.push({id:id('audit'),timestamp:now(),...event,...extra});state.audit=state.audit.slice(-5000);save();}
function emit(type,data={}){const e={id:id('evt'),type,timestamp:now(),data};state.events.push(e);state.events=state.events.slice(-5000);audit({event:type}, {data});}
function providerConfig(provider){const p=(provider||'').toLowerCase();if(p==='openai'||p==='apex')return{kind:'openai',key:process.env.OPENAI_API_KEY,base:'https://api.openai.com/v1',model:process.env.OPENAI_MODEL||'gpt-5.6-luna'};if(p==='deepseek')return{kind:'openai',key:process.env.DEEPSEEK_API_KEY,base:'https://api.deepseek.com/v1',model:process.env.DEEPSEEK_MODEL||'deepseek-chat'};if(p==='compatible')return{kind:'openai',key:process.env.COMPAT_API_KEY,base:process.env.COMPAT_BASE_URL,model:process.env.COMPAT_MODEL};if(p==='anthropic')return{kind:'anthropic',key:process.env.ANTHROPIC_API_KEY,base:'https://api.anthropic.com',model:process.env.ANTHROPIC_MODEL||'claude-sonnet-4-6'};if(p==='google')return{kind:'google',key:process.env.GOOGLE_API_KEY,base:'https://generativelanguage.googleapis.com/v1beta',model:process.env.GOOGLE_MODEL||'gemini-2.5-flash'};return null;}
async function callModel({provider,model,messages,max_tokens=1200}){const cfg=providerConfig(provider);if(!cfg?.key||!cfg.base)throw Object.assign(new Error('MODEL_PROVIDER_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});if(cfg.kind==='openai'){const r=await fetch(cfg.base.replace(/\/$/,'')+'/chat/completions',{method:'POST',headers:{'content-type':'application/json','authorization':'Bearer '+cfg.key},body:JSON.stringify({model:model&&model!=='apex-astra'?model:cfg.model,messages,max_tokens,temperature:.35})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||`Provider HTTP ${r.status}`);return d?.choices?.[0]?.message?.content||'';}
if(cfg.kind==='anthropic'){const system=messages.find(x=>x.role==='system')?.content||'';const mm=messages.filter(x=>x.role!=='system').map(x=>({role:x.role==='assistant'?'assistant':'user',content:String(x.content)}));const r=await fetch(cfg.base+'/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':cfg.key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:cfg.model,max_tokens,messages:mm,system})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||`Provider HTTP ${r.status}`);return (d.content||[]).filter(x=>x.type==='text').map(x=>x.text).join('');}
if(cfg.kind==='google'){const prompt=messages.map(x=>`${x.role.toUpperCase()}: ${x.content}`).join('\n\n');const r=await fetch(`${cfg.base}/models/${encodeURIComponent(cfg.model)}:generateContent?key=${encodeURIComponent(cfg.key)}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{maxOutputTokens:max_tokens,temperature:.35}})});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.error?.message||`Provider HTTP ${r.status}`);return d?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('')||'';}}
function localChat(message){
 const q=String(message||'').trim();
 const l=q.toLowerCase();
 if(!q) return 'Tell me what you want OMEGA to do.';
 if(/build|website|web app|app|dashboard|landing page|site/.test(l)) return `OMEGA local builder is ready. Open Builder and describe the app/website. I can generate a runnable HTML/CSS/JS build and render it in the live preview.\n\nRequest received: ${q}`;
 if(/status|health|online|running/.test(l)) return 'OMEGA backend is online. Persistent state, missions, approvals, audit and the live builder are available.';
 if(/help|what can you do|features/.test(l)) return 'I can manage projects, goals, approvals, audit events, schedules, channel connectors, and build/rerender websites or app interfaces in the live preview. External connectors require their server-side credentials.';
 return `OMEGA received: ${q}\n\nLocal execution mode is active. No external AI provider is required for the core workspace, builder, preview, persistence and control-plane features.`;
}
function localBuild(prompt){
 const p=String(prompt||'').replace(/[<>]/g,'');
 const l=p.toLowerCase();
 let title='APEX OMEGA APP', accent='#8b5cf6', accent2='#22d3ee';
 if(/car|race|racing/.test(l)){title='APEX RACING';accent='#ef4444';accent2='#f59e0b'}
 else if(/shop|store|ecommerce/.test(l)){title='OMEGA STORE';accent='#ec4899';accent2='#8b5cf6'}
 else if(/finance|analytics|dashboard/.test(l)){title='OMEGA DASHBOARD';accent='#22c55e';accent2='#06b6d4'}
 else if(/cyber|security/.test(l)){title='OMEGA SECURITY';accent='#22c55e';accent2='#06b6d4'}
 return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title}</title><style>*{box-sizing:border-box}body{margin:0;background:#07070c;color:#fff;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.nav{display:flex;justify-content:space-between;align-items:center;padding:18px 6%;border-bottom:1px solid #252535;background:#0b0c12;position:sticky;top:0}.live{color:${accent2}}.wrap{max-width:1100px;margin:auto;padding:60px 6%}.hero{font-size:clamp(42px,9vw,92px);line-height:.94;margin:18px 0;background:linear-gradient(90deg,${accent},${accent2});color:transparent;background-clip:text}.muted{color:#9ca3b7;line-height:1.7}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:30px}.card{padding:24px;border:1px solid #29293a;border-radius:18px;background:#11121b}.btn{padding:12px 18px;border:0;border-radius:10px;background:${accent};color:#fff;font-weight:800;cursor:pointer}@media(max-width:700px){.grid{grid-template-columns:1fr}.wrap{padding-top:35px}}</style></head><body><nav class="nav"><b>${title}</b><span class="live">LIVE PREVIEW</span></nav><main class="wrap"><div class="muted">Generated by APEX OMEGA local builder</div><h1 class="hero">${title}</h1><p class="muted">${p}</p><button class="btn" onclick="this.textContent='Action complete ✓'">Test interaction</button><div class="grid"><section class="card"><b>Real UI</b><p class="muted">Interactive HTML, CSS and JavaScript.</p></section><section class="card"><b>Live</b><p class="muted">Rendered immediately inside the isolated preview.</p></section><section class="card"><b>Exportable</b><p class="muted">Edit the source and export a standalone HTML file.</p></section></div></main></body></html>`;
}
function statusForGoal(g){return g.status||'PLANNED';}
function safeToolRegistry(){return [
{name:'WEB_SEARCH',permission:'LOW',risk:'LOW',configured:!!process.env.SEARCH_API_KEY,description:'Search configured web provider'},
{name:'BROWSER',permission:'MEDIUM',risk:'MEDIUM',configured:false,description:'Browser automation requires a supported computer-control runtime'},
{name:'FILE_READ',permission:'LOW',risk:'LOW',configured:true,description:'Server workspace file read'},
{name:'FILE_WRITE',permission:'MEDIUM',risk:'MEDIUM',configured:true,description:'Server workspace file write'},
{name:'CODE_EXECUTION',permission:'HIGH',risk:'HIGH',configured:false,description:'Sandbox runtime must be explicitly configured'},
{name:'DATABASE',permission:'HIGH',risk:'HIGH',configured:false,description:'Database connector not configured'},
{name:'HTTP_REQUEST',permission:'MEDIUM',risk:'MEDIUM',configured:true,description:'Outbound HTTP with server-side policy'},
{name:'EMAIL',permission:'HIGH',risk:'HIGH',configured:false,description:'Email provider not configured'},
{name:'CALENDAR',permission:'HIGH',risk:'HIGH',configured:false,description:'Calendar provider not configured'},
{name:'NOTIFICATION',permission:'LOW',risk:'LOW',configured:true,description:'In-app notifications'},
{name:'N8N_WORKFLOW',permission:'HIGH',risk:'HIGH',configured:!!process.env.N8N_BASE_URL,description:'Configured n8n webhook integration'},
{name:'GITHUB',permission:'HIGH',risk:'HIGH',configured:false,description:'GitHub OAuth/token connector not configured'},
{name:'CLOUD_STORAGE',permission:'HIGH',risk:'HIGH',configured:false,description:'Cloud storage connector not configured'}];}
async function runGoal(g){if(g.status==='CANCELLED'||g.status==='COMPLETED')return;g.status='RUNNING';g.updatedAt=now();emit('goal.started',{goalId:g.id});
const plan=`Goal: ${g.description}\nPriority: ${g.priority}\nDeadline: ${g.deadline||'none'}\nCreate a concise executable task graph with dependencies, tools, risk levels, verification steps, and approval gates. Do not claim external execution.`;
let planner;try{planner=await callModel({provider:'openai',messages:[{role:'system',content:'You are APEX OMEGA Orchestrator. Return valid JSON with tasks:[{title,description,dependencyIds,tool,risk,requiresApproval,verification}] and summary. Never invent tool availability.'},{role:'user',content:plan}],max_tokens:1800});}catch(e){g.status='FAILED';g.error=e.message;emit('task.failed',{goalId:g.id,error:e.message});return;}
let parsed;try{parsed=JSON.parse(planner.replace(/^```json\s*|```$/g,''));}catch{parsed={tasks:[{title:'Planner output review',description:planner,dependencyIds:[],tool:'NONE',risk:'LOW',requiresApproval:false,verification:'Human review'}],summary:'Planner returned non-JSON output; review required.'};}
g.plan=parsed;g.tasks=[];for(const t of (parsed.tasks||[])){const tid=id('task');state.tasks[tid]={id:tid,goalId:g.id,title:t.title,description:t.description,status:t.requiresApproval?'WAITING_APPROVAL':'PLANNED',dependencyIds:t.dependencyIds||[],tool:t.tool||'NONE',risk:t.risk||'LOW',requiresApproval:!!t.requiresApproval,verification:t.verification||'',createdAt:now(),updatedAt:now()};g.tasks.push(tid);emit('task.created',{goalId:g.id,taskId:tid});}
g.progress=0;g.updatedAt=now();save();emit('goal.plan_created',{goalId:g.id,taskCount:g.tasks.length});
}

// ═══ MULTI-CHANNEL REAL AGENTS ═══
// Credentials are server-side only. Each adapter is disabled until its required
// environment variables are configured. No fake/simulated sends are performed.
const channelConfig=()=>({
  whatsapp:{configured:!!(process.env.WHATSAPP_ACCESS_TOKEN&&process.env.WHATSAPP_PHONE_NUMBER_ID),name:'WhatsApp Cloud API'},
  telegram:{configured:!!process.env.TELEGRAM_BOT_TOKEN,name:'Telegram Bot API'},
  instagram:{configured:!!(process.env.INSTAGRAM_ACCESS_TOKEN&&process.env.INSTAGRAM_PAGE_ID),name:'Instagram Messaging via Meta Graph API'},
  messenger:{configured:!!(process.env.MESSENGER_PAGE_ACCESS_TOKEN&&process.env.MESSENGER_PAGE_ID),name:'Facebook Messenger'},
  discord:{configured:!!process.env.DISCORD_WEBHOOK_URL,name:'Discord Webhook'},
  slack:{configured:!!process.env.SLACK_WEBHOOK_URL,name:'Slack Incoming Webhook'},
  email:{configured:!!process.env.RESEND_API_KEY,name:'Email via Resend'},
  n8n:{configured:!!process.env.N8N_BASE_URL,name:'n8n Webhook Bridge'},
  webhook:{configured:true,name:'Generic Webhook'}
});
function verifyToken(req, expected){return !!expected && (req.headers['x-apex-webhook-token']===expected || req.headers['x-telegram-bot-api-secret-token']===expected);}
async function postJson(url,body,headers={}){const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',...headers},body:JSON.stringify(body)});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d?.description||d?.message||`HTTP ${r.status}`);return d;}
async function sendChannel(channel,to,text,meta={}){
  const c=channel.toLowerCase();
  if(c==='whatsapp'){
    if(!process.env.WHATSAPP_ACCESS_TOKEN||!process.env.WHATSAPP_PHONE_NUMBER_ID)throw Object.assign(new Error('WHATSAPP_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson(`https://graph.facebook.com/v23.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,{messaging_product:'whatsapp',to:String(to),type:'text',text:{body:String(text)}},{authorization:`Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`});
  }
  if(c==='telegram'){
    if(!process.env.TELEGRAM_BOT_TOKEN)throw Object.assign(new Error('TELEGRAM_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`,{chat_id:to,text:String(text)});
  }
  if(c==='instagram'){
    if(!process.env.INSTAGRAM_ACCESS_TOKEN)throw Object.assign(new Error('INSTAGRAM_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    const recipientId=meta.recipientId||to;
    return postJson('https://graph.facebook.com/v23.0/me/messages',{recipient:{id:String(recipientId)},message:{text:String(text)}},{authorization:`Bearer ${process.env.INSTAGRAM_ACCESS_TOKEN}`});
  }
  if(c==='messenger'){
    if(!process.env.MESSENGER_PAGE_ACCESS_TOKEN)throw Object.assign(new Error('MESSENGER_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson('https://graph.facebook.com/v23.0/me/messages',{recipient:{id:String(to)},message:{text:String(text)}},{authorization:`Bearer ${process.env.MESSENGER_PAGE_ACCESS_TOKEN}`});
  }
  if(c==='discord'){
    if(!process.env.DISCORD_WEBHOOK_URL)throw Object.assign(new Error('DISCORD_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson(process.env.DISCORD_WEBHOOK_URL,{content:String(text)});
  }
  if(c==='slack'){
    if(!process.env.SLACK_WEBHOOK_URL)throw Object.assign(new Error('SLACK_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson(process.env.SLACK_WEBHOOK_URL,{text:String(text)});
  }
  if(c==='email'){
    if(!process.env.RESEND_API_KEY||!process.env.EMAIL_FROM)throw Object.assign(new Error('EMAIL_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    return postJson('https://api.resend.com/emails',{from:process.env.EMAIL_FROM,to:[String(to)],subject:meta.subject||'APEX AI Agent',text:String(text)},{authorization:`Bearer ${process.env.RESEND_API_KEY}`});
  }
  if(c==='n8n'){
    if(!process.env.N8N_BASE_URL)throw Object.assign(new Error('N8N_NOT_CONFIGURED'),{code:'CONFIG_REQUIRED'});
    const url=process.env.N8N_BASE_URL.replace(/\/$/,'')+(meta.path||'/webhook/apex-ai');
    return postJson(url,{channel:c,to,message:String(text),data:meta.data||{}},process.env.N8N_API_KEY?{authorization:`Bearer ${process.env.N8N_API_KEY}`}:{})
  }
  if(c==='webhook'){
    if(!meta.url)throw new Error('WEBHOOK_URL_REQUIRED');
    return postJson(meta.url,{channel:c,to,message:String(text),data:meta.data||{}});
  }
  throw new Error(`UNSUPPORTED_CHANNEL:${channel}`);
}
async function agentReply(channel,input,meta={}){
  const provider=meta.provider||process.env.DEFAULT_AI_PROVIDER||'openai';
  const system=meta.system||`You are APEX AI ${channel} Agent. Reply naturally and helpfully. Do not claim an action was completed unless the server actually completed it. Keep replies concise for messaging.`;
  return callModel({provider,messages:[{role:'system',content:system},{role:'user',content:String(input)}],max_tokens:Number(meta.maxTokens||700)});
}
function channelAgents(){const c=channelConfig();return Object.entries(c).map(([id,v])=>({id,name:v.name,configured:v.configured,real:true,mode:'agent'}));}

function tickSchedules(){const t=Date.now();for(const s of Object.values(state.schedules)){if(!s.enabled||s.nextRun>t)continue;const gid=id('goal');const g={id:gid,description:s.goalDescription,priority:s.priority||'NORMAL',deadline:null,status:'PLANNED',owner:'scheduler',tasks:[],progress:0,createdAt:now(),updatedAt:now(),requiredPermissions:[]};state.goals[gid]=g;s.lastRun=now();s.nextRun=t+(s.intervalMs||86400000);save();runGoal(g).catch(()=>{});emit('schedule.triggered',{scheduleId:s.id,goalId:gid});}}
setInterval(tickSchedules,5000);

const server=http.createServer(async(req,res)=>{try{
if(req.method==='GET'&&req.url==='/'){return html(res,path.join(__dirname,'index.html'));}
if(req.method==='GET'&&req.url==='/api/health')return send(res,200,{ok:true,service:'APEX AI OMEGA',time:now(),storage:'json-persistent',modelProviders:{openai:!!process.env.OPENAI_API_KEY,anthropic:!!process.env.ANTHROPIC_API_KEY,google:!!process.env.GOOGLE_API_KEY,deepseek:!!process.env.DEEPSEEK_API_KEY}});
if(req.method==='GET'&&req.url==='/api/tools')return send(res,200,{tools:safeToolRegistry()});
if(req.method==='POST'&&req.url==='/api/chat'){const b=await body(req);try{let reply;let mode='server-model';try{reply=await callModel(b);}catch(e){if(e.code!=='CONFIG_REQUIRED')throw e;reply=localChat((b.messages||[]).filter(x=>x.role==='user').at(-1)?.content||b.message);mode='local-runtime';}audit({event:'model.completed',tool:mode==='local-runtime'?'LOCAL_RUNTIME':'MODEL',inputSummary:'chat request',outputSummary:String(reply).slice(0,500),provider:b.provider||'openai',mode});return send(res,200,{reply,mode,activities:[{label:mode==='local-runtime'?'Built-in OMEGA runtime':'Server-side model execution',ok:true},{label:'API secret isolated from browser',ok:true}],sources:[]});}catch(e){audit({event:'model.failed',tool:'MODEL',error:e.message});return send(res,e.code==='CONFIG_REQUIRED'?503:502,{error:e.message,code:e.code||'MODEL_ERROR'});}}
if(req.method==='POST'&&req.url==='/api/build'){const b=await body(req);const prompt=String(b.prompt||'').trim();if(!prompt)return send(res,400,{error:'prompt required'});try{let html='',mode='server-model';try{const system='You are the APEX OMEGA frontend builder. Return ONLY one complete self-contained HTML document. Use inline CSS and JS, responsive layout, accessible controls, and no markdown fences. The result must run inside a sandboxed iframe. Never claim an external action happened. User request: '+prompt;const reply=await callModel({provider:b.provider||'openai',model:b.model,messages:[{role:'system',content:system},{role:'user',content:prompt}],max_tokens:7000});html=String(reply||'').trim().replace(/^```(?:html)??\s*/i,'').replace(/```$/,'').trim();}catch(e){if(e.code!=='CONFIG_REQUIRED')throw e;html=localBuild(prompt);mode='local-runtime';}if(!/<html[\s>]/i.test(html))return send(res,502,{error:'BUILDER_DID_NOT_RETURN_HTML'});audit({event:'builder.completed',tool:mode==='local-runtime'?'LOCAL_BUILDER':'MODEL_BUILD',inputSummary:prompt.slice(0,500),outputSummary:html.slice(0,500),provider:b.provider||'openai',mode});return send(res,200,{ok:true,html,mode});}catch(e){audit({event:'builder.failed',tool:'MODEL_BUILD',error:e.message});return send(res,e.code==='CONFIG_REQUIRED'?503:502,{ok:false,error:e.message,code:e.code||'BUILD_ERROR'});}}
if(req.method==='GET'&&req.url==='/api/goals')return send(res,200,{goals:Object.values(state.goals)});
if(req.method==='POST'&&req.url==='/api/goals'){const b=await body(req);if(!b.description)return send(res,400,{error:'description required'});const gid=id('goal');const g={id:gid,description:String(b.description),priority:b.priority||'NORMAL',deadline:b.deadline||null,owner:b.owner||'user',status:'PLANNED',tasks:[],dependencies:b.dependencies||[],progress:0,requiredPermissions:b.requiredPermissions||[],approvalState:'NONE',executionHistory:[],createdAt:now(),updatedAt:now()};state.goals[gid]=g;save();emit('goal.created',{goalId:gid});if(b.autoPlan!==false)runGoal(g).catch(()=>{});return send(res,201,g);}
const gm=req.url.match(/^\/api\/goals\/([^/]+)\/run$/);if(req.method==='POST'&&gm){const g=state.goals[gm[1]];if(!g)return send(res,404,{error:'goal not found'});await runGoal(g);return send(res,200,g);}
const gc=req.url.match(/^\/api\/goals\/([^/]+)\/cancel$/);if(req.method==='POST'&&gc){const g=state.goals[gc[1]];if(!g)return send(res,404,{error:'goal not found'});g.status='CANCELLED';g.updatedAt=now();save();emit('goal.cancelled',{goalId:g.id});return send(res,200,g);}
if(req.method==='GET'&&req.url==='/api/tasks')return send(res,200,{tasks:Object.values(state.tasks)});
if(req.method==='GET'&&req.url==='/api/projects')return send(res,200,{projects:Object.values(state.projects)});
if(req.method==='POST'&&req.url==='/api/projects'){const b=await body(req);const pid=id('project');const p={id:pid,name:String(b.name||'Untitled Project'),description:b.description||'',createdAt:now(),updatedAt:now()};state.projects[pid]=p;save();return send(res,201,p);}
if(req.method==='GET'&&req.url==='/api/memory')return send(res,200,{memory:Object.values(state.memory)});
if(req.method==='POST'&&req.url==='/api/memory'){const b=await body(req);if(!b.content)return send(res,400,{error:'content required'});const mid=id('mem');const m={id:mid,content:String(b.content),scope:b.scope||'project',approved:b.approved===true,createdAt:now(),updatedAt:now(),expiresAt:b.expiresAt||null};state.memory[mid]=m;save();return send(res,201,m);}
if(req.method==='GET'&&req.url==='/api/permissions')return send(res,200,{permissions:Object.values(state.permissions)});
if(req.method==='POST'&&req.url==='/api/permissions'){const b=await body(req);const pid=id('perm');const p={id:pid,scope:b.scope||'project',tool:b.tool||'*',decision:b.decision||'ASK',risk:b.risk||'HIGH',expiresAt:b.expiresAt||null,createdAt:now()};state.permissions[pid]=p;save();return send(res,201,p);}
if(req.method==='GET'&&req.url==='/api/approvals')return send(res,200,{approvals:Object.values(state.approvals).filter(x=>x.status==='PENDING')});
if(req.method==='POST'&&req.url==='/api/approvals'){const b=await body(req);const aid=id('approval');const a={id:aid,action:b.action||'',reason:b.reason||'',tool:b.tool||'UNKNOWN',risk:b.risk||'HIGH',reversible:b.reversible!==false,status:'PENDING',createdAt:now()};state.approvals[aid]=a;save();emit('approval.requested',{approvalId:aid});return send(res,201,a);}
const ar=req.url.match(/^\/api\/approvals\/([^/]+)\/(approve|deny)$/);if(req.method==='POST'&&ar){const a=state.approvals[ar[1]];if(!a)return send(res,404,{error:'approval not found'});a.status=ar[2]==='approve'?'APPROVED':'DENIED';a.decidedAt=now();save();emit(a.status==='APPROVED'?'approval.granted':'approval.denied',{approvalId:a.id});return send(res,200,a);}
if(req.method==='GET'&&req.url==='/api/audit')return send(res,200,{audit:state.audit.slice(-1000).reverse()});
if(req.method==='GET'&&req.url==='/api/events')return send(res,200,{events:state.events.slice(-500)});
if(req.method==='GET'&&req.url==='/api/notifications')return send(res,200,{notifications:state.notifications.slice(-200).reverse()});
if(req.method==='POST'&&req.url==='/api/notifications'){const b=await body(req);const n={id:id('note'),message:String(b.message||''),type:b.type||'INFO',createdAt:now(),read:false};state.notifications.push(n);save();return send(res,201,n);}
if(req.method==='GET'&&req.url==='/api/schedules')return send(res,200,{schedules:Object.values(state.schedules)});
if(req.method==='POST'&&req.url==='/api/schedules'){const b=await body(req);const interval=Math.max(60000,Number(b.intervalMs||86400000));const s={id:id('sched'),goalDescription:String(b.goalDescription||''),intervalMs:interval,nextRun:Date.now()+interval,enabled:b.enabled!==false,priority:b.priority||'NORMAL',createdAt:now()};state.schedules[s.id]=s;save();return send(res,201,s);}

if(req.method==='GET'&&req.url==='/api/agents/channels')return send(res,200,{agents:channelAgents()});
if(req.method==='POST'&&req.url==='/api/agents/send'){const b=await body(req);if(!b.channel||!b.to||!b.message)return send(res,400,{error:'channel, to and message required'});try{const result=await sendChannel(b.channel,b.to,b.message,b);audit({event:'agent.message.sent',tool:`CHANNEL:${b.channel}`,inputSummary:String(b.message).slice(0,500),result:'ok'});return send(res,200,{ok:true,channel:b.channel,to:b.to,result});}catch(e){audit({event:'agent.message.failed',tool:`CHANNEL:${b.channel}`,error:e.message});return send(res,e.code==='CONFIG_REQUIRED'?503:502,{ok:false,error:e.message,code:e.code||'CHANNEL_ERROR'});}}
if(req.method==='POST'&&req.url==='/api/agents/reply'){const b=await body(req);if(!b.channel||!b.to||!b.message)return send(res,400,{error:'channel, to, message required'});try{const reply=await agentReply(b.channel,b.message,b);const result=await sendChannel(b.channel,b.to,reply,b);audit({event:'agent.reply.completed',tool:`AGENT:${b.channel}`,inputSummary:String(b.message).slice(0,500),outputSummary:String(reply).slice(0,500),result:'ok'});return send(res,200,{ok:true,reply,result});}catch(e){audit({event:'agent.reply.failed',tool:`AGENT:${b.channel}`,error:e.message});return send(res,e.code==='CONFIG_REQUIRED'?503:502,{ok:false,error:e.message,code:e.code||'AGENT_ERROR'});}}
const wh=req.url.match(/^\/api\/webhooks\/([^/?]+)(?:\?.*)?$/);
if(req.method==='GET'&&wh){const ch=wh[1].toLowerCase();if(ch==='whatsapp'||ch==='instagram'||ch==='messenger'){const u=new URL(req.url,'http://localhost');const mode=u.searchParams.get('hub.mode');const token=u.searchParams.get('hub.verify_token');const challenge=u.searchParams.get('hub.challenge');const expected=process.env[`${ch.toUpperCase()}_VERIFY_TOKEN`];if(mode==='subscribe'&&token&&expected&&token===expected)return send(res,200,{challenge});}return send(res,403,{error:'WEBHOOK_VERIFICATION_FAILED'});}
if(req.method==='POST'&&wh){const ch=wh[1].toLowerCase();const b=await body(req);try{
 let incoming='',to='',meta={};
 if(ch==='telegram'){const m=b.message||b.edited_message;if(!m)return send(res,200,{ok:true,ignored:true});incoming=m.text||'';to=m.chat?.id;meta.recipientId=to;if(process.env.TELEGRAM_WEBHOOK_SECRET&&!verifyToken(req,process.env.TELEGRAM_WEBHOOK_SECRET))return send(res,401,{error:'invalid secret'});}
 else if(ch==='whatsapp'){const msg=b?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];if(!msg)return send(res,200,{ok:true,ignored:true});incoming=msg.text?.body||msg.button?.text||'';to=msg.from;meta.recipientId=to;if(!process.env.WHATSAPP_VERIFY_TOKEN) return send(res,503,{error:'WHATSAPP_VERIFY_TOKEN not configured'});}
 else if(ch==='instagram'){const msg=b?.entry?.[0]?.messaging?.[0];if(!msg||!msg.message?.text)return send(res,200,{ok:true,ignored:true});incoming=msg.message.text;to=msg.sender?.id;meta.recipientId=to;}
 else if(ch==='messenger'){const msg=b?.entry?.[0]?.messaging?.[0];if(!msg||!msg.message?.text)return send(res,200,{ok:true,ignored:true});incoming=msg.message.text;to=msg.sender?.id;}
 else {incoming=b.message||b.text||'';to=b.to||b.recipient||b.chat_id||'';meta.data=b.data||b;}
 if(!incoming||!to)return send(res,400,{error:'message/recipient not found'});
 const reply=await agentReply(ch,incoming,meta);await sendChannel(ch,to,reply,meta);audit({event:'agent.inbound.completed',tool:`AGENT:${ch}`,inputSummary:String(incoming).slice(0,500),outputSummary:String(reply).slice(0,500),result:'ok'});return send(res,200,{ok:true,reply});
}catch(e){audit({event:'agent.inbound.failed',tool:`AGENT:${ch}`,error:e.message});return send(res,e.code==='CONFIG_REQUIRED'?503:502,{ok:false,error:e.message,code:e.code||'AGENT_ERROR'});}}
if(req.method==='GET'&&req.url==='/api/omega/status')return send(res,200,{ok:true,killSwitch:false,autonomy:'SUPERVISED',activeGoals:Object.values(state.goals).filter(g=>g.status==='RUNNING').length,pendingApprovals:Object.values(state.approvals).filter(a=>a.status==='PENDING').length,tools:safeToolRegistry(),storage:DB});
return send(res,404,{error:'NOT_FOUND'});
}catch(e){return send(res,500,{error:e.message||'INTERNAL_ERROR'});}});
server.listen(PORT,()=>console.log(`APEX AI OMEGA listening on http://localhost:${PORT}`));
