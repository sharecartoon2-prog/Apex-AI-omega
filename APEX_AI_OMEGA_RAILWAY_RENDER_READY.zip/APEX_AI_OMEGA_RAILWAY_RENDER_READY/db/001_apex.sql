-- APEX AI OMEGA persistent schema. Functions also initialize it idempotently.
CREATE TABLE IF NOT EXISTS apex_goals(id TEXT PRIMARY KEY,description TEXT NOT NULL,priority TEXT NOT NULL DEFAULT 'MEDIUM',deadline TIMESTAMPTZ NULL,status TEXT NOT NULL DEFAULT 'PLANNED',owner TEXT NOT NULL DEFAULT 'user',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),progress INTEGER NOT NULL DEFAULT 0,required_permissions JSONB NOT NULL DEFAULT '[]',approval_state TEXT NOT NULL DEFAULT 'NOT_REQUIRED',dependencies JSONB NOT NULL DEFAULT '[]');
CREATE TABLE IF NOT EXISTS apex_tasks(id TEXT PRIMARY KEY,goal_id TEXT NOT NULL REFERENCES apex_goals(id) ON DELETE CASCADE,title TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PLANNED',agent TEXT NOT NULL DEFAULT 'Orchestrator',dependencies JSONB NOT NULL DEFAULT '[]',progress INTEGER NOT NULL DEFAULT 0,retry_count INTEGER NOT NULL DEFAULT 0,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS apex_memory(id TEXT PRIMARY KEY,scope TEXT NOT NULL DEFAULT 'project',project_id TEXT NULL,user_id TEXT NULL,content TEXT NOT NULL,metadata JSONB NOT NULL DEFAULT '{}',created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE INDEX IF NOT EXISTS idx_apex_memory_scope ON apex_memory(scope);
CREATE TABLE IF NOT EXISTS apex_approvals(id TEXT PRIMARY KEY,action TEXT NOT NULL,risk TEXT NOT NULL DEFAULT 'HIGH',status TEXT NOT NULL DEFAULT 'PENDING',requested_by TEXT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),resolved_at TIMESTAMPTZ NULL);
CREATE TABLE IF NOT EXISTS apex_audit(id BIGSERIAL PRIMARY KEY,timestamp TIMESTAMPTZ NOT NULL DEFAULT NOW(),agent TEXT NULL,goal_id TEXT NULL,task_id TEXT NULL,tool TEXT NULL,event TEXT NOT NULL,input_summary TEXT NULL,output_summary TEXT NULL,permission_decision TEXT NULL,approval_decision TEXT NULL,result TEXT NULL,error TEXT NULL,retry_count INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS idx_apex_audit_time ON apex_audit(timestamp DESC);
CREATE TABLE IF NOT EXISTS apex_schedules(id TEXT PRIMARY KEY,goal_id TEXT NULL REFERENCES apex_goals(id) ON DELETE SET NULL,cron TEXT NOT NULL,timezone TEXT NOT NULL DEFAULT 'UTC',enabled BOOLEAN NOT NULL DEFAULT TRUE,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW());
CREATE TABLE IF NOT EXISTS apex_projects(id TEXT PRIMARY KEY,name TEXT NOT NULL,description TEXT NULL,created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW());

CREATE INDEX IF NOT EXISTS idx_apex_tasks_goal_status ON apex_tasks(goal_id,status);
CREATE INDEX IF NOT EXISTS idx_apex_audit_goal_time ON apex_audit(goal_id,timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_apex_memory_scope_project ON apex_memory(scope,project_id,created_at DESC);
