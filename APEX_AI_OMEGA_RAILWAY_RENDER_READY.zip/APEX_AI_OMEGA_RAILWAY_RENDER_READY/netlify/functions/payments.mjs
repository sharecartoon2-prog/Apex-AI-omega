import crypto from 'node:crypto';
import { db } from './_db.mjs';

const PLANS = {
  pro:   { name: 'APEX AI PRO',   amount: 499,  currency: 'INR', days: 30 },
  ultra: { name: 'APEX AI ULTRA', amount: 999,  currency: 'INR', days: 30 },
  elite: { name: 'APEX AI ELITE', amount: 2499, currency: 'INR', days: 30 }
};

const json = (status, body) => ({
  statusCode: status,
  headers: { 'content-type': 'application/json', 'cache-control': 'no-store' },
  body: JSON.stringify(body)
});

function cfg() {
  const required = ['PHONEPE_CLIENT_ID', 'PHONEPE_CLIENT_SECRET', 'PHONEPE_CLIENT_VERSION'];
  const missing = required.filter(k => !process.env[k]);
  if (missing.length) throw Object.assign(new Error(`PHONEPE_NOT_CONFIGURED: ${missing.join(', ')}`), { code: 'CONFIG_REQUIRED' });
  const env = String(process.env.PHONEPE_ENV || 'SANDBOX').toUpperCase();
  return {
    env,
    authUrl: env === 'PRODUCTION'
      ? 'https://api.phonepe.com/apis/identity-manager/v1/oauth/token'
      : 'https://api-preprod.phonepe.com/apis/pg-sandbox/v1/oauth/token',
    payUrl: env === 'PRODUCTION'
      ? 'https://api.phonepe.com/apis/pg/checkout/v2/pay'
      : 'https://api-preprod.phonepe.com/apis/pg-sandbox/checkout/v2/pay',
    statusBase: env === 'PRODUCTION'
      ? 'https://api.phonepe.com/apis/pg/checkout/v2/order'
      : 'https://api-preprod.phonepe.com/apis/pg-sandbox/checkout/v2/order'
  };
}

let tokenCache = { token: null, expiresAt: 0 };

async function phonepeToken() {
  const c = cfg();
  if (tokenCache.token && Date.now() < tokenCache.expiresAt - 60_000) return tokenCache.token;
  const body = new URLSearchParams({
    client_id: process.env.PHONEPE_CLIENT_ID,
    client_version: process.env.PHONEPE_CLIENT_VERSION,
    client_secret: process.env.PHONEPE_CLIENT_SECRET,
    grant_type: 'client_credentials'
  });
  const r = await fetch(c.authUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || !d.access_token) throw new Error(d.message || `PhonePe auth failed (${r.status})`);
  tokenCache = { token: d.access_token, expiresAt: Number(d.expires_at || 0) * 1000 || Date.now() + 30 * 60_000 };
  return tokenCache.token;
}

async function ppFetch(url, options = {}) {
  const token = await phonepeToken();
  const r = await fetch(url, {
    ...options,
    headers: {
      'content-type': 'application/json',
      authorization: `O-Bearer ${token}`,
      ...(options.headers || {})
    }
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.message || d.code || `PhonePe HTTP ${r.status}`);
  return d;
}

function safeId() {
  return `APEX_${Date.now()}_${crypto.randomBytes(5).toString('hex')}`.slice(0, 63);
}

async function init() {
  const sql = db();
  await sql`CREATE TABLE IF NOT EXISTS apex_payments(
    id TEXT PRIMARY KEY,
    provider TEXT NOT NULL,
    order_id TEXT UNIQUE,
    phonepe_order_id TEXT,
    payment_id TEXT UNIQUE,
    plan_id TEXT NOT NULL,
    amount_paise INTEGER NOT NULL,
    currency TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'CREATED',
    customer_email TEXT,
    customer_name TEXT,
    metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    paid_at TIMESTAMPTZ NULL,
    expires_at TIMESTAMPTZ NULL,
    raw JSONB
  )`;
  await sql`ALTER TABLE apex_payments ADD COLUMN IF NOT EXISTS phonepe_order_id TEXT`;
  await sql`CREATE TABLE IF NOT EXISTS apex_entitlements(
    id TEXT PRIMARY KEY,
    customer_email TEXT,
    plan_id TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    starts_at TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    payment_id TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
}

async function fulfil(orderId, statusPayload) {
  const sql = db();
  const rows = await sql`SELECT * FROM apex_payments WHERE order_id=${orderId} LIMIT 1`;
  if (!rows.length) return { ok: false, error: 'ORDER_NOT_FOUND' };
  const rec = rows[0];
  const plan = PLANS[rec.plan_id];
  if (!plan) return { ok: false, error: 'UNKNOWN_PLAN' };
  const amount = Number(statusPayload.amount ?? -1);
  if (amount !== Number(rec.amount_paise)) return { ok: false, error: 'PAYMENT_AMOUNT_MISMATCH' };

  const txn = statusPayload.paymentDetails?.find(x => x.state === 'COMPLETED')?.transactionId
    || statusPayload.paymentDetails?.[0]?.transactionId
    || null;
  const expires = new Date(Date.now() + plan.days * 86400000).toISOString();

  await sql`UPDATE apex_payments
    SET payment_id=COALESCE(payment_id, ${txn}), status='PAID', paid_at=COALESCE(paid_at,NOW()),
        expires_at=${expires}, raw=${JSON.stringify(statusPayload)}
    WHERE order_id=${orderId}`;

  if (txn) {
    await sql`INSERT INTO apex_entitlements(id,customer_email,plan_id,status,starts_at,expires_at,payment_id)
      VALUES(${`ent_${crypto.randomBytes(10).toString('hex')}`},${rec.customer_email},${rec.plan_id},'ACTIVE',NOW(),${expires},${txn})
      ON CONFLICT DO NOTHING`;
  }
  return { ok: true, status: 'PAID', planId: rec.plan_id, expiresAt: expires, transactionId: txn };
}

export async function handler(event) {
  try {
    await init();
    const method = event.httpMethod || 'GET';
    const body = event.body ? (event.isBase64Encoded ? Buffer.from(event.body, 'base64').toString('utf8') : event.body) : '';
    const data = body ? JSON.parse(body) : {};

    if (method === 'GET') {
      const qs = event.queryStringParameters || {};
      if (qs.action === 'config') {
        const configured = ['PHONEPE_CLIENT_ID', 'PHONEPE_CLIENT_SECRET', 'PHONEPE_CLIENT_VERSION'].every(k => !!process.env[k]);
        return json(200, { ok: true, provider: 'phonepe', configured, environment: String(process.env.PHONEPE_ENV || 'SANDBOX').toUpperCase(), plans: Object.fromEntries(Object.entries(PLANS).map(([k, v]) => [k, { ...v, amountPaise: v.amount * 100 }])) });
      }
      if (qs.action === 'status' && qs.orderId) {
        const sql = db();
        const rows = await sql`SELECT * FROM apex_payments WHERE order_id=${qs.orderId} LIMIT 1`;
        if (!rows.length) return json(404, { ok: false, error: 'ORDER_NOT_FOUND' });
        const rec = rows[0];
        const c = cfg();
        const status = await ppFetch(`${c.statusBase}/${encodeURIComponent(rec.order_id)}/status?details=true`);
        if (status.state === 'COMPLETED') {
          const result = await fulfil(rec.order_id, status);
          return json(200, result);
        }
        if (status.state === 'FAILED') await sql`UPDATE apex_payments SET status='FAILED',raw=${JSON.stringify(status)} WHERE order_id=${rec.order_id}`;
        return json(200, { ok: true, status: status.state || 'PENDING', phonePe: status });
      }
      return json(405, { ok: false, error: 'METHOD_NOT_ALLOWED' });
    }

    if (method !== 'POST') return json(405, { ok: false, error: 'METHOD_NOT_ALLOWED' });

    if (data.action === 'create-order') {
      const p = PLANS[data.planId];
      if (!p) return json(400, { ok: false, error: 'UNKNOWN_PLAN' });
      if (!data.email) return json(400, { ok: false, error: 'EMAIL_REQUIRED' });
      const base = String(process.env.APP_BASE_URL || '').replace(/\/$/, '') || `https://${event.headers?.host || ''}`;
      if (!/^https:\/\//i.test(base)) return json(503, { ok: false, error: 'APP_BASE_URL_HTTPS_REQUIRED' });

      const merchantOrderId = safeId();
      const redirectUrl = `${base}/payment-return.html?orderId=${encodeURIComponent(merchantOrderId)}`;
      const c = cfg();
      const created = await ppFetch(c.payUrl, {
        method: 'POST',
        body: JSON.stringify({
          merchantOrderId,
          amount: p.amount * 100,
          expireAfter: 1800,
          paymentFlow: {
            type: 'PG_CHECKOUT',
            message: `${p.name} — 30 days`,
            merchantUrls: { redirectUrl }
          },
          metaInfo: {
            udf1: data.planId,
            udf2: String(data.email).slice(0, 256),
            udf3: 'APEX_AI'
          }
        })
      });

      const sql = db();
      await sql`INSERT INTO apex_payments(id,provider,order_id,phonepe_order_id,plan_id,amount_paise,currency,status,customer_email,customer_name,metadata,raw)
        VALUES(${`payrec_${crypto.randomBytes(10).toString('hex')}`},'phonepe',${merchantOrderId},${created.orderId || null},${data.planId},${p.amount * 100},'INR','CREATED',${data.email},${data.name || null},${JSON.stringify({})},${JSON.stringify(created)})`;
      return json(200, { ok: true, provider: 'phonepe', environment: c.env, merchantOrderId, phonePeOrderId: created.orderId, state: created.state, redirectUrl: created.redirectUrl, amount: p.amount * 100, currency: 'INR', planId: data.planId, name: p.name });
    }

    if (data.action === 'status') {
      if (!data.orderId) return json(400, { ok: false, error: 'ORDER_ID_REQUIRED' });
      const sql = db();
      const rows = await sql`SELECT * FROM apex_payments WHERE order_id=${data.orderId} LIMIT 1`;
      if (!rows.length) return json(404, { ok: false, error: 'ORDER_NOT_FOUND' });
      const rec = rows[0];
      const c = cfg();
      const status = await ppFetch(`${c.statusBase}/${encodeURIComponent(rec.order_id)}/status?details=true`);
      if (status.state === 'COMPLETED') return json(200, await fulfil(rec.order_id, status));
      if (status.state === 'FAILED') await sql`UPDATE apex_payments SET status='FAILED',raw=${JSON.stringify(status)} WHERE order_id=${rec.order_id}`;
      return json(200, { ok: true, status: status.state || 'PENDING' });
    }

    if (data.action === 'entitlement') {
      const sql = db();
      const rows = await sql`SELECT plan_id,status,expires_at,payment_id FROM apex_entitlements WHERE customer_email=${data.email || ''} AND status='ACTIVE' AND expires_at>NOW() ORDER BY expires_at DESC LIMIT 1`;
      return json(200, { ok: true, entitlement: rows[0] || null });
    }

    return json(400, { ok: false, error: 'UNKNOWN_ACTION' });
  } catch (e) {
    console.error(e);
    return json(e?.code === 'CONFIG_REQUIRED' ? 503 : 500, { ok: false, error: e?.code === 'CONFIG_REQUIRED' ? 'PHONEPE_NOT_CONFIGURED' : (e.message || 'PAYMENT_ERROR') });
  }
}
