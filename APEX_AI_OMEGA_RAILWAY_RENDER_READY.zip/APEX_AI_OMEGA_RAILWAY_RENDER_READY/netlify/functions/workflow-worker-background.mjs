import crypto from 'node:crypto';
import {db} from './_db.mjs';
import {ensureSchema,audit} from './_store.mjs';
import {runWorkflow} from './workflow-engine.mjs';

export default async()=>{
  await ensureSchema();
  const sql=db();
  const worker=crypto.randomUUID();
  // Recover abandoned locks so a timed-out worker does not permanently strand a run.
  await sql`UPDATE apex_workflow_jobs SET status='QUEUED',locked_at=NULL,locked_by=NULL,updated_at=NOW() WHERE status='RUNNING' AND locked_at < NOW() - INTERVAL '5 minutes'`;
  let processed=0;
  while(processed<10){
    const jobs=await sql`UPDATE apex_workflow_jobs SET status='RUNNING',locked_at=NOW(),locked_by=${worker},attempts=attempts+1,updated_at=NOW() WHERE id=(SELECT id FROM apex_workflow_jobs WHERE status='QUEUED' AND available_at<=NOW() ORDER BY created_at FOR UPDATE SKIP LOCKED LIMIT 1) RETURNING *`;
    if(!jobs.length)break;
    const j=jobs[0];
    const [w]=await sql`SELECT * FROM apex_workflows WHERE id=${j.workflow_id}`;
    const [run]=await sql`SELECT * FROM apex_workflow_runs WHERE id=${j.run_id}`;
    if(!w||!run){await sql`UPDATE apex_workflow_jobs SET status='FAILED',last_error='WORKFLOW_OR_RUN_NOT_FOUND',updated_at=NOW() WHERE id=${j.id}`;processed++;continue;}
    try{
      await sql`UPDATE apex_workflow_runs SET status='RUNNING',error=NULL WHERE id=${j.run_id}`;
      const output=await runWorkflow({workflow:w,runId:j.run_id,input:run.input,startIndex:Number(run.checkpoint||0)});
      await sql`UPDATE apex_workflow_runs SET status='COMPLETED',output=${JSON.stringify(output)},finished_at=NOW() WHERE id=${j.run_id}`;
      await sql`UPDATE apex_workflow_jobs SET status='COMPLETED',locked_at=NULL,locked_by=NULL,updated_at=NOW() WHERE id=${j.id}`;
      await audit({event:'workflow.worker.completed',tool:'WORKFLOW_WORKER',outputSummary:`run=${j.run_id}`});
    }catch(e){
      const retry=j.attempts<j.max_attempts;
      await sql`UPDATE apex_workflow_runs SET status=${retry?'QUEUED':'FAILED'},error=${e.message},finished_at=${retry?null:new Date()} WHERE id=${j.run_id}`;
      if(retry) await sql`UPDATE apex_workflow_jobs SET status='QUEUED',available_at=NOW()+INTERVAL '5 seconds',locked_at=NULL,locked_by=NULL,last_error=${e.message},updated_at=NOW() WHERE id=${j.id}`;
      else await sql`UPDATE apex_workflow_jobs SET status='FAILED',locked_at=NULL,locked_by=NULL,last_error=${e.message},updated_at=NOW() WHERE id=${j.id}`;
      await audit({event:'workflow.worker.failed',tool:'WORKFLOW_WORKER',error:e.message,retryCount:j.attempts});
    }
    processed++;
  }
  return {ok:true,processed};
};
