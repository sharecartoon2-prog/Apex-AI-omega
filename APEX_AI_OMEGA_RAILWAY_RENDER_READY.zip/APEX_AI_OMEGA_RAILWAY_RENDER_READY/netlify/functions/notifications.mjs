import { json } from "./_utils.mjs";
export default async () => json({ok:true,notifications:[],status:"READY"});
