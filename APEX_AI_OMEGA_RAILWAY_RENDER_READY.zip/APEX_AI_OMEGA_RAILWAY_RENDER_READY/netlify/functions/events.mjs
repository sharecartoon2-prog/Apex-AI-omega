import { json, body, method, now } from "./_utils.mjs";
const events = globalThis.__apexEvents ??= [];
export default async (event) => {
  if(method(event)==="GET") return json({ok:true,events});
  if(method(event)!=="POST") return json({ok:false,error:"Method not allowed"},405);
  const input=body(event); const e={id:crypto.randomUUID(),type:input.type||"custom",payload:input.payload||{},timestamp:now()};
  events.push(e); return json({ok:true,event:e},201);
};
