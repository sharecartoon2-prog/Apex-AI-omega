import crypto from 'node:crypto';
import { db } from './_db.mjs';

const json = (status, body) => ({ statusCode: status, headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });

function safeEqual(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
}

function verifyHmac(raw, signature, secret) {
  if (!signature || !secret) return false;
  const expectedHex = crypto.createHmac('sha256', secret).update(raw).digest('hex');
  const expectedB64 = crypto.createHmac('sha256', secret).update(raw).digest('base64');
  return safeEqual(signature, expectedHex) || safeEqual(signature, expectedB64);
}

function verifyLegacy(raw, signature, saltKey, saltIndex) {
  if (!signature || !saltKey || saltIndex === undefined) return false;
  const expected = crypto.createHash('sha256').update(Buffer.from(raw).toString('base64') + saltKey).digest('hex') + `###${saltIndex}`;
  return safeEqual(signature, expected);
}

export async function handler(event) {
  try {
    if (event.httpMethod !== 'POST') return json(405, { ok: false, error: 'METHOD_NOT_ALLOWED' });
    const raw = event.isBase64Encoded ? Buffer.from(event.body || '', 'base64').toString('utf8') : (event.body || '');
    const h = event.headers || {};
    const signature = h['x-phonepe-checksum-signature'] || h['X-PhonePe-Checksum-Signature'] || h['x-verify'] || h['X-VERIFY'];
    const valid = verifyHmac(raw, signature, process.env.PHONEPE_WEBHOOK_SECRET) || verifyLegacy(raw, signature, process.env.PHONEPE_SALT_KEY, process.env.PHONEPE_SALT_INDEX);
    if (!valid) return json(401, { ok: false, error: 'INVALID_WEBHOOK_SIGNATURE' });

    const payload = JSON.parse(raw);
    const orderId = payload?.payload?.merchantOrderId || payload?.merchantOrderId || payload?.orderId;
    const state = payload?.payload?.state || payload?.state;
    if (!orderId) return json(200, { ok: true, ignored: true });

    const sql = db();
    const rows = await sql`SELECT * FROM apex_payments WHERE order_id=${orderId} LIMIT 1`;
    if (!rows.length) return json(200, { ok: true, ignored: true });

    if (state === 'COMPLETED') {
      const rec = rows[0];
      const amount = Number(payload?.payload?.amount ?? payload?.amount ?? -1);
      if (amount !== Number(rec.amount_paise)) return json(400, { ok: false, error: 'PAYMENT_AMOUNT_MISMATCH' });
      const txn = payload?.payload?.paymentDetails?.find(x => x.state === 'COMPLETED')?.transactionId || null;
      const planDays = { pro: 30, ultra: 30, elite: 30 }[rec.plan_id] || 30;
      const expires = new Date(Date.now() + planDays * 86400000).toISOString();
      await sql`UPDATE apex_payments SET payment_id=COALESCE(payment_id,${txn}),status='PAID',paid_at=COALESCE(paid_at,NOW()),expires_at=${expires},raw=${JSON.stringify(payload)} WHERE order_id=${orderId}`;
      if (txn) await sql`INSERT INTO apex_entitlements(id,customer_email,plan_id,status,starts_at,expires_at,payment_id)
        VALUES(${`ent_${crypto.randomBytes(10).toString('hex')}`},${rec.customer_email},${rec.plan_id},'ACTIVE',NOW(),${expires},${txn}) ON CONFLICT DO NOTHING`;
    } else if (state === 'FAILED') {
      await sql`UPDATE apex_payments SET status='FAILED',raw=${JSON.stringify(payload)} WHERE order_id=${orderId}`;
    } else {
      await sql`UPDATE apex_payments SET raw=${JSON.stringify(payload)} WHERE order_id=${orderId}`;
    }
    return json(200, { ok: true, received: true });
  } catch (e) {
    console.error(e);
    return json(500, { ok: false, error: e.message || 'WEBHOOK_ERROR' });
  }
}
