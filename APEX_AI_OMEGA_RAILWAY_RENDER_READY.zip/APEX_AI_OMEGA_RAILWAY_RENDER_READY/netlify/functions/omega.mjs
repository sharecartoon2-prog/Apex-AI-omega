import { json, body, method } from './_utils.mjs';
import { db, configError } from './_db.mjs';
import { ensureSchema, audit } from './_store.mjs';

const plannerSystem = `You are APEX AI OMEGA Planner. Convert a user's goal into a safe executable mission graph. Return ONLY valid JSON: {"summary":string,"risk":"LOW|MEDIUM|HIGH","requiresApproval":boolean,"tasks":[{"title":string,"agent":"Research|Coding|Browser|Data|File|Automation|Writing|QA|Verification","dependencies":[],"risk":"LOW|MEDIUM|HIGH","verification":string}],"clarifications":[]}. Never invent credentials, claim execution, or bypass authentication/CAPTCHA/security controls. HIGH-risk or irreversible actions require approval.`;

async function callProvider(messages, provider, model) {
  const p=(provider||process.env.DEFAULT_AI_PROVIDER||'openai').toLowerCase();
  const defaults={openai:process.env.OPENAI_MODEL||'gpt-5',anthropic:process.env.ANTHROPIC_MODEL||'claude-3-5-sonnet-latest',google:process.env.GOOGLE_MODEL||'gemini-2.5-flash',deepseek:process.env.DEEPSEEK_MODEL||'deepseek-chat'};
  const m=model||defaults[p]; let r,data,text;
  if(p==='openai'||p==='deepseek'){
    const key=p==='openai'?process.env.OPENAI_API_KEY:process.env.DEEPSEEK_API_KEY;
    if(!key) throw new Error(`${p.toUpperCase()}_API_KEY is not configured`);
    const url=p==='openai'?'https://api.openai.com/v1/chat/completions':'https://api.deepseek.com/chat/completions';
    r=await fetch(url,{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${key}`},body:JSON.stringify({model:m,messages,response_format:{type:'json_object'}})});
    data=await r.json(); text=data?.choices?.[0]?.message?.content;
  } else if(p==='anthropic'){
    if(!process.env.ANTHROPIC_API_KEY) throw new Error('ANTHROPIC_API_KEY is not configured');
    const system=messages.filter(x=>x.role==='system').map(x=>x.content).join('\n');
    r=await fetch('https://api.anthropic.com/v1/messages',{method:'POST',headers:{'content-type':'application/json','x-api-key':process.env.ANTHROPIC_API_KEY,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:m,max_tokens:4096,system,messages:messages.filter(x=>x.role!=='system')})});
    data=await r.json(); text=data?.content?.find(x=>x.type==='text')?.text;
  } else if(p==='google'){
    if(!process.env.GOOGLE_API_KEY) throw new Error('GOOGLE_API_KEY is not configured');
    const system=messages.filter(x=>x.role==='system').map(x=>x.content).join('\n');
    const contents=messages.filter(x=>x.role!=='system').map(x=>({role:x.role==='assistant'?'model':'user',parts:[{text:String(x.content)}]}));
    r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(m)}:generateContent?key=${encodeURIComponent(process.env.GOOGLE_API_KEY)}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({systemInstruction:{parts:[{text:system}]},contents,generationConfig:{responseMimeType:'application/json'}})});
    data=await r.json(); text=data?.candidates?.[0]?.content?.parts?.map(x=>x.text||'').join('');
  } else throw new Error(`Unsupported provider: ${p}`);
  return {r,data,text,provider:p,model:m};
}
function parseJson(s){return JSON.parse(String(s||'').replace(/^```json\s*/i,'').replace(/\s*```$/,'').trim());}
export default async event=>{
 try{
  if(method(event)!=='POST') return json({ok:false,error:'Method not allowed'},405);
  await ensureSchema(); const x=body(event); const goal=String(x.goal||x.description||'').trim();
  if(!goal) return json({ok:false,error:'goal is required'},400);
  const p=await callProvider([{role:'system',content:plannerSystem},{role:'user',content:goal}],x.provider,x.model);
  if(!p.r.ok) return json({ok:false,status:'UPSTREAM_ERROR',provider:p.provider,model:p.model,error:p.data},p.r.status);
  let plan; try{plan=parseJson(p.text)}catch(_){return json({ok:false,status:'PLANNER_INVALID_JSON',raw:p.text},502)}
  const tasks=Array.isArray(plan.tasks)?plan.tasks:[]; if(!tasks.length) return json({ok:false,status:'NO_TASKS_GENERATED',plan},422);
  const sql=db(),goalId=crypto.randomUUID(),risk=['LOW','MEDIUM','HIGH'].includes(plan.risk)?plan.risk:'MEDIUM';
  const needs=Boolean(plan.requiresApproval||risk==='HIGH'||tasks.some(t=>t.risk==='HIGH'));
  await sql`INSERT INTO apex_goals(id,description,priority,status,required_permissions,approval_state) VALUES(${goalId},${goal},${risk},${needs?'WAITING_APPROVAL':'PLANNED'},${JSON.stringify(tasks.map(t=>t.risk||'MEDIUM'))},${needs?'REQUIRED':'NOT_REQUIRED'})`;
  const created=[];
  for(let i=0;i<tasks.length;i++){
   const t=tasks[i]||{},id=crypto.randomUUID();
   const deps=Array.isArray(t.dependencies)?t.dependencies.map(n=>Number.isInteger(n)?(created[n]?.id||String(n)):String(n)):[];
   await sql`INSERT INTO apex_tasks(id,goal_id,title,status,agent,dependencies) VALUES(${id},${goalId},${String(t.title||`Task ${i+1}`)},${needs?'BLOCKED':'PLANNED'},${String(t.agent||'Orchestrator')},${JSON.stringify(deps)})`;
   created.push({id,title:t.title||`Task ${i+1}`,agent:t.agent||'Orchestrator',risk:t.risk||'MEDIUM',verification:t.verification||'Verify output before completion',dependencies:deps});
  }
  if(needs) await sql`INSERT INTO apex_approvals(id,action,risk,status,requested_by) VALUES(${crypto.randomUUID()},${`Approve OMEGA mission ${goalId}`},${risk},'PENDING','OMEGA Planner')`;
  await audit({event:'omega.plan.created',goalId,agent:'OMEGA Planner',inputSummary:goal,outputSummary:`${created.length} tasks; risk ${risk}; approval ${needs?'required':'not required'}`,permissionDecision:needs?'BLOCKED_UNTIL_APPROVAL':'ALLOWED'});
  return json({ok:true,mission:{goalId,goal,risk,requiresApproval:needs,summary:plan.summary||'',clarifications:plan.clarifications||[],tasks:created},execution:'PLANNED_ONLY'},201);
 }catch(err){if(configError(err))return json({ok:false,status:'CONFIG_REQUIRED',message:err.message},503);return json({ok:false,status:'OMEGA_ERROR',error:err.message},500)}
};
