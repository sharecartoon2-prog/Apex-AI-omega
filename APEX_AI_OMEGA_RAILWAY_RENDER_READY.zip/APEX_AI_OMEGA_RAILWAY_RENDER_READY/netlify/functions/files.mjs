import { json } from "./_utils.mjs";
export default async () => json({ok:false,status:"CONFIG_REQUIRED",message:"Persistent file storage is not configured. Connect a storage provider before enabling file writes."},503);
