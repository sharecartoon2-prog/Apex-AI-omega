import { json } from "./_utils.mjs";
const agents = [
  ["Orchestrator","Goal planning and task routing"],
  ["Research Agent","Research and evidence collection"],
  ["Coding Agent","Code generation and debugging"],
  ["Browser Agent","Permitted browser workflows"],
  ["Data Agent","Structured data analysis"],
  ["File Agent","Permitted file operations"],
  ["Automation Agent","Approved workflows"],
  ["Writing Agent","Reports and documentation"],
  ["QA Agent","Testing and consistency checks"],
  ["Verification Agent","Independent verification"]
];
export default async () => json({
  ok:true,
  agents:agents.map(([name,description])=>({name,description,status:"AVAILABLE"}))
});
