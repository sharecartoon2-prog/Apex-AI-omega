export function json(data, statusCode = 200, headers = {}) {
  return {
    statusCode,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
      ...headers
    },
    body: JSON.stringify(data)
  };
}

export function method(event) {
  return event.httpMethod || "GET";
}

export function body(event) {
  if (!event.body) return {};
  try { return JSON.parse(event.body); }
  catch { return {}; }
}

export function requireEnv(name) {
  return Boolean(process.env[name] && process.env[name].trim());
}

export function unavailable(name, extra = {}) {
  return json({
    ok: false,
    status: "UNAVAILABLE",
    tool: name,
    message: `${name} is not configured on this deployment.`,
    ...extra
  }, 503);
}

export function now() {
  return new Date().toISOString();
}
