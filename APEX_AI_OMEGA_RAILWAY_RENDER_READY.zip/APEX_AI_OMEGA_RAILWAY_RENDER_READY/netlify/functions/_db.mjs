import { neon } from '@neondatabase/serverless';
let client;
export function db(){
  if(!process.env.DATABASE_URL){const e=new Error('DATABASE_URL is not configured.');e.code='CONFIG_REQUIRED';throw e;}
  client ||= neon(process.env.DATABASE_URL); return client;
}
export function configError(e){return e?.code==='CONFIG_REQUIRED' || /DATABASE_URL is not configured/.test(String(e?.message));}
