import { json, body, method, now } from "./_utils.mjs";
const policies = globalThis.__apexPolicies ??= [];
export default async (event) => {
  const m=method(event);
  if(m==="GET") return json({ok:true,policies});
  if(m!=="POST") return json({ok:false,error:"Method not allowed"},405);
  const input=body(event);
  const p={id:crypto.randomUUID(),tool:input.tool||"*",decision:input.decision||"ASK",scope:input.scope||"project",createdAt:now()};
  policies.push(p);
  return json({ok:true,policy:p},201);
};
