# APEX AI OMEGA — REAL FULL-STACK v2

## The important fix
The previous package used `netlify dev` without shipping the Netlify CLI. That could make the app fail to start. This build starts directly with Node:

```bash
npm start
```

or:

```bash
node server.mjs
```

Then open:

`http://localhost:8787`

## What works without an external AI provider
The core OMEGA control plane and builder now have a real local runtime fallback:

- real HTTP backend
- persistent JSON state
- chat route (`/api/chat`)
- website/app builder (`/api/build`)
- live sandboxed preview
- editable HTML/CSS/JS
- missions/goals
- approvals
- audit log
- schedules/state
- connector status
- channel-agent routes
- exportable generated HTML

The local builder is deterministic rather than pretending to be a hidden LLM. If you configure a server-side model provider, `/api/chat` and `/api/build` use that provider; otherwise OMEGA stays functional in local-runtime mode.

## Optional model providers
Set one or more server-side environment variables. Never put provider secrets in `index.html`.

```bash
OPENAI_API_KEY=...
OPENAI_MODEL=...
```

Other providers supported by the server are documented in `server.mjs`.

## Real external automation
WhatsApp, Telegram, Instagram/Messenger, Discord, Slack, email, n8n and other connectors only become active after their actual credentials/webhooks are configured. No fake success responses are used.

High-impact external actions are approval/connector gated by design.

## Why the live preview is real
The Builder returns actual HTML and immediately assigns it to an isolated `iframe.srcdoc`. Buttons and JavaScript inside the generated project can execute in that preview. The parent OMEGA UI remains isolated from the generated project.
