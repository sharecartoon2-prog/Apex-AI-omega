# APEX AI OMEGA — Railway / Render deployment

## Railway
1. Create a new Railway project.
2. Choose Deploy from GitHub or upload/import this project.
3. Railway detects Node automatically.
4. Start command is already set to `npm start` in `railway.json`.
5. After deployment, open the generated public domain.
6. Health check: `/api/health`.

## Render
1. Create a new Web Service and connect this repository/project.
2. Build command: `npm install`
3. Start command: `npm start`
4. Health check: `/api/health`.
5. `render.yaml` contains the same settings for Blueprint deployment.

## Environment variables
Add provider credentials in the hosting dashboard, not in `index.html`.
Useful variables are documented in `.env.example`.

Minimum for local-runtime mode: none.
For real server-side AI: set `OPENAI_API_KEY` (or another supported provider key).

## Persistence
The bundled runtime stores state in `data/omega-state.json`. Ephemeral hosting filesystems may reset after redeploy/restart. For durable production state, attach persistent storage or migrate the state layer to PostgreSQL before treating the JSON file as production persistence.
